<?php

// Point d'entrée principal de l'application web (public/index.php)
// Charge l'autoloader Composer pour les dépendances
require __DIR__ . '/../vendor/autoload.php';

// Ici, on pourrait faire du routing plus avancé (ex : router vers différents contrôleurs selon l'URL)
// Pour l'instant, on redirige simplement vers l'ancien tableau de bord principal
header('Location: /ffp3/ffp3datas/ffp3-data.php', true, 302);
exit; 