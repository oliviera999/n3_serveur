<!DOCTYPE HTML>
<!--
	farmflow datas by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<?Php
require "config.php";// Database connection
//require "esp-database.php";
    include_once('config.php');

    if ($_GET["readingsCount"]){
      $data = $_GET["readingsCount"];
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      $readings_count = $_GET["readingsCount"];
    }
    // default readings count set to 2000
    else {
      $readings_count = 1500;
    }
    
 $last_reading = getLastReadings();   
 $last_reading_time = $last_reading["reading_time"];
 
  $first_reading = getAllReadings2();
  $first_reading2 = $first_reading ["max_amount2"];
    
    $last_reading_time2 = getLastReadings2($readings_count);
    $last_reading_time3 = $last_reading_time2 ["min_amount2"];
    // Uncomment to set timezone to - 1 hour (you can change 1 to any number)
    $last_reading_time = date("d/m/Y H:i:s", strtotime("$last_reading_time - 1 hours"));
    $last_reading_time4 = date("d/m/Y H:i:s", strtotime("$last_reading_time3 - 1 hours"));
    ?>
<html>
	<head>
		<title>farmflow datas</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>

	</head>
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper" class="fade-in">
				<!-- Header -->
					<header id="header">
						<a href="index.php" class="logo">farmflow datas</a>
					</header>

				<!-- Nav -->
					<nav id="nav">
						<ul class="links">
							<li><a href="https://iot.olution.info/index.php">connecté</a></li>
							<li><a href="http://iot.olution.info/esp-weather-station.php">données</a></li>
							<li><a href="https://iot.olution.info/gallery.php">images</a></li>
							<li classe="active"><a href="https://iot.olution.info/esp-data.php">historique</a></li>
						</ul>
						<ul class="icons">
							<li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
							<li><a href="#" class="icon brands fa-discord"><span class="label">Discord</span></a></li>
						</ul>
					</nav>

				<!-- Main -->
					<div id="main">

						<!-- Featured Post -->
							<article class="post featured">
								<header class="major">
									<h2>Historique des paramètres
									</h2>
									<p>Le système est suivi grâce à la carte de développement ESP-32 qui mesure température de l'eau, niveau d'eau, température de l'air, et humidité. Les résultats sont transmis très régulièrement.</p>
									<p>Il est possible de zoomer sur les graphs (clic droit pour revenir au zoom initial).</p>
                                    <h3 style="text-align: center"><?php echo $readings_count; ?> enregistrements analys&eacute;s sur <?php echo $first_reading2; ?> </h3> 
                                    <h3 style="text-align: center">du <?php echo $last_reading_time4; ?> au <?php echo $last_reading_time; ?></h3>
                                    <form method="get">
                                        <input type="number" name="readingsCount" min="1" placeholder="Enregistrements à analyser (<?php echo $readings_count; ?>)">
                                        <input type="submit" value="Mettre a jour">
                                    </form>
								</header>



<?Php
if($stmt = $connection->query("SELECT reading_time,TempAir,Humidite,Humid1,Humid2,Humid3,Humid4,Luminosite FROM SensorData2 order by reading_time desc limit " . $readings_count . " ")){

//  echo "No of records : ".$stmt->num_rows."<br>";
$php_data_array = Array(); // create PHP array
//  echo "<table>
//<tr> <th>id</th><th>TempAir</th><th>Humidite</th><th>Exp Fxd</th><th>Exp Vrv</th></tr>";
while ($row = $stmt->fetch_row()) {
//   echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td><td>$row[6]</td><td>$row[7]</td></tr>";
   $php_data_array[] = $row; // Adding to array
   }
//echo "</table>";
}else{
echo $connection->error;
}
//print_r( $php_data_array);
// You can display the json_encode output here. 
//echo json_encode($php_data_array); 

// Transfor PHP array to JavaScript two dimensional array 
echo "<script>
        var my_2d = ".json_encode($php_data_array)."
</script>";
?>

<table class="columns">
      <tr>
        <h3 text-align=center>Les niveaux d'eau de l'aquarium et de la réserve</h3>
        <div id="curve_chart4" style="margin-left:0px;width:100%;height:400px;border:1px solid #DDD;overflow:hidden"></div>
      </tr>

      <tr>
          <br>
          <h3 text-align=center>Le niveau d'eau du potager</h3>
          <div id="curve_chart3" style="margin-left:0px;width:100%;height:400px;border:1px solid #DDD;overflow:hidden"></div>
      </tr>

      <tr>
          <br>
          <h3 text-align=center>Les températures de l'eau et de l'air</h3>
          <div id="curve_chart" style="margin-left:0px;width:100%;height:400px;border:1px solid #DDD;overflow:hidden"></div>
      </tr>
      
      <tr>
          <br>
          <h3 text-align=center>L'humidité de l'air</h3>
          <div id="curve_chart2" style="margin-left:0px;width:100%;height:400px;border:1px solid #DDD;overflow:hidden"></div>
      </tr>

      <tr>
          <br>
          <h3 text-align=center>Luminosité</h3>
          <div id="curve_chart5" style="margin-left:0px;width:100%;height:400px;border:1px solid #DDD;overflow:hidden"></div>
      </tr>

    </table>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
	  
  
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('datetime', 'reading_time');
        data.addColumn('number', 'température air');
		data.addColumn('number', 'température eau');
		
		

        for(i = 0; i < my_2d.length; i++)
            data.addRow([new Date(my_2d[i][0]), parseFloat(my_2d[i][1]),parseFloat(my_2d[i][3])]);
       var options = {
          title: 'Températures (°C)',
                            hAxis: {
          title: 'Date',
          format: 'dd/MM/yyyy HH:mm'
          
        },
                            vAxis: {format:'0.00'},
            curveType: 'function',
        chartArea: {left: 50, top: 20, right: 25, bottom: 75 },
        legend: { position: 'bottom' },
        explorer: { actions: ['dragToZoom', 'rightClickToReset'] },
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
        chart.draw(data, options);
       }
	///////////////////////////////
</script>

<script type="text/javascript">

    

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('datetime', 'reading_time');
		data.addColumn('number', 'humidite');

        for(i = 0; i < my_2d.length; i++)
        data.addRow([new Date(my_2d[i][0]),parseFloat(my_2d[i][2])]);
       var options = {
          title: 'Humidité (%)',
                  hAxis: {
          title: 'Date',
          format: 'dd/MM/yyyy HH:mm',

        },
        
        curveType: 'function',
        chartArea: {left: 50, top: 50, right: 25, bottom: 75 },
          legend: { position: 'none' },
          explorer: { actions: ['dragToZoom', 'rightClickToReset'] },
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart2'));
        chart.draw(data, options);
       }
	///////////////////////////////
</script>

<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('datetime', 'reading_time');
		data.addColumn('number', 'niveau eau');
        for(i = 0; i < my_2d.length; i++)
    data.addRow([new Date(my_2d[i][0]),parseInt(my_2d[i][4])]);
       var options = {
          title: 'Niveau eau (UA)',
        curveType: 'function',
                  hAxis: {
          title: 'Date',
          format: 'dd/MM/yyyy HH:mm',
        },
               chartArea: {left: 50, top: 25, right: 25, bottom: 75 },
          legend: { position: 'none' },
                    explorer: { actions: ['dragToZoom', 'rightClickToReset'] },

        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart3'));
        chart.draw(data, options);
       }
	///////////////////////////////
</script>

<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('datetime', 'reading_time');
        data.addColumn('number', 'eau aquarium');
		data.addColumn('number', 'eau reserve');

        for(i = 0; i < my_2d.length; i++)
    data.addRow([new Date(my_2d[i][0]), parseInt(my_2d[i][5]),parseInt(my_2d[i][6])]);
       var options = {
          title: 'Distance eau (cm)',
                            hAxis: {
          title: 'Date',
          format: 'dd/MM/yyyy HH:mm',

        },
        curveType: 'function',
        chartArea: {left: 50, top: 20, right: 25, bottom: 75 },
        legend: { position: 'bottom' },
        explorer: { actions: ['dragToZoom', 'rightClickToReset'] },
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart4'));
        chart.draw(data, options);


       }
	///////////////////////////////
</script>

<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('datetime', 'reading_time');
		data.addColumn('number', 'luminosite');
        for(i = 0; i < my_2d.length; i++)
    data.addRow([new Date(my_2d[i][0]),parseInt(my_2d[i][7])]);
       var options = {
          title: 'Luminosité (UA)',
        curveType: 'function',
        hAxis: {
          title: 'Date',
          format: 'dd/MM/yyyy HH:mm',
        },
        
            curveType: 'function',
            chartArea: {left: 50, top: 25, right: 25, bottom: 75 },
            legend: { position: 'none' },
            explorer: { actions: ['dragToZoom', 'rightClickToReset'] },

        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart5'));
        chart.draw(data, options);
       }
	///////////////////////////////
</script>

						<!-- Posts -->


				<!-- Copyright -->
			</div>


		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>